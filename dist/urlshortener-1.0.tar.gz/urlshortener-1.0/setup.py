from distutils.core import setup

setup(
    name='urlshortener',
    version='1.0',
    packages=['urlshortener', 'urlshortener_app'],
    url='',
    license='',
    author='riccardo',
    author_email='',
    description=''
)
